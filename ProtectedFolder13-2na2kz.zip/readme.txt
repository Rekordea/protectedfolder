Installation

Unzip the package you`ve downloaded and install the software by running Setup.exe.
Upon the first launch set up the master password and then register the software using the registration info below.

-----------------------------------------------------------------------------------------

Registration key:

E83EE-0D5D4-076AA-DE6B9

-----------------------------------------------------------------------------------------

You have to install and activate it before the Giveaway offer for the software is over.

Terms and conditions

Please note that the software you download and install 
during the Giveaway period comes with the following important limitations:
1) No free technical support
2) No free upgrades to future versions
3) Strictly non-commercial usage